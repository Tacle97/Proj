<?php
include('config.php');
session_start();
if (!isset($_SESSION['tenant'])) {
    header("location:index.php");
}

$id = $_GET['landlord_id'];

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style/home.css">
    <link rel="stylesheet" href="./fontawesome-free-6.5.1-web/css/all.min.css">
</head>

<body class="parent">

    <header class="header">
        <nav class="navigation">
            <ul>
                <li><a href="home.php">Home</a></li>
                <li><a href="">About Us</a></li>
                <li><a href="">Services</a></li>
                <li><a href="logout.php">Logout</a></li>
            </ul>
        </nav>
        <div class="menu">
            <h2 class="bars fa-solid fa-bars"></h2>
            <div class="burger">
                <ul>
                    <li><a href="home.php">Home</a></li>
                    <li><a href="">About Us</a></li>
                    <li><a href="">Services</a></li>
                    <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </header>

    <div class="hero">

        <div class="box padding-50">
            <div>
                <h1 class="title">HOTEL</h1>
                <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Ducimus quaerat ipsum quos cumque possimus expedita distinctio repudiandae magnam veniam. Quidem accusantium placeat repellendus modi dolores? Vitae optio vel asperiores nam inventore facere repudiandae quos sapiente sequi quo velit aliquid saepe dolores aut odio, et dignissimos quidem reiciendis ab, impedit est.</p>
            </div>
        </div>
        <div class="box">
            <img src="./image/herov2-removebg-preview.png" alt="" width="400px">
        </div>

    </div>
    <main class="main">

       
    <?php

    $sql = "select * from rooms where bh_id = $id";
    $res = mysqli_query($connection, $sql);

    while ($row = mysqli_fetch_assoc($res)) {
        $room_id = $row['id'];
        $room_name = $row['room_name'];
        $image = $row['image'];
        $tenant_id = $row['tenant_id'];
        if($tenant_id != ''){
            $html = <<<HTML
                    <div class="room">
                        <div class="image">
                            <img src="./room/$image" alt="room" >
                            
                        </div>
                        <div class="text-section">
                            <h2 class="room-title"><mark>OCCUPIED</mark></h2>
                            <div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt repellendus ea fugit aliquid qui vitae a hic quod quas consectetur! Vitae iste repudiandae animi eligendi natus harum quod architecto doloremque.</p>
                            </div>
                        </div>
                    </div>
            HTML;
    
            echo $html;
        }else{
            $html = <<<HTML
                <a href="takerooom.php?room_id=$room_id">
                    <div class="room">
                        <div class="image">
                            <img src="./room/$image" alt="room" >
                            
                        </div>
                        <div class="text-section">
                            <h2 class="room-title">$room_name</h2>
                            <div>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt repellendus ea fugit aliquid qui vitae a hic quod quas consectetur! Vitae iste repudiandae animi eligendi natus harum quod architecto doloremque.</p>
                            </div>
                        </div>
                    </div>
                </a>
            HTML;
    
            echo $html;
        }

        
    }


    ?>


    </main>

    <footer class="footer">


    </footer>

</body>

</html>