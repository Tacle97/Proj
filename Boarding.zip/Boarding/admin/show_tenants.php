<?php 

include('../config.php');

if(isset($_GET['landlord_id'])){
    $id = $_GET['landlord_id'];
    $sql = "select tenants.id , tenants.name, tenants.email, tenants.number from tenants inner join rooms on tenants.id = rooms.tenant_id where rooms.bh_id = $id; ";
    $res = mysqli_query($connection,$sql);

    $table = <<<HTML
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Contact Number</th>
                </tr>
            </thead>
            <tbody>   
    HTML;

    echo $table;

    while($row = mysqli_fetch_assoc($res)){
        $id = $row['id'];
        $name = $row['name'];
        $email = $row['email'];
        $number = $row['number'];
        $html = <<<HTML
            <tr>
                <td>$id</td>
                <td>$name</td>
                <td>$email</td>
                <td>$number</td>
            </tr>            
        HTML;

        echo $html;
    }
        echo "</tbody>";
    echo "</table>";

}


?>