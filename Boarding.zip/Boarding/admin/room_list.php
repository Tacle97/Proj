<?php 
include('../config.php');
if(isset($_GET['landlord_id'])){
    
    $id = $_GET['landlord_id'];
    $sql =" select rooms.id,rooms.room_name, rooms.image, rooms.tenant_id from rooms inner join landlords
    on rooms.bh_id = landlords.id where landlords.id = $id";
    $res = mysqli_query($connection,$sql);

    while($row = mysqli_fetch_assoc($res)){
        $id = $row['id'];
        $room_name = $row['room_name'];
        $image = $row['image'];
        $tenant_id = $row['tenant_id'];

        if($tenant_id != ''){
            $table = <<<HTML
                <div class="room">
                    <div class="image">
                        <img src="../rooms/$image" alt="room" width='300px' height='200px'>
                    </div>
                    <div class="text-section">
                        <h2 class="room-title"><mark>OCCUPIED</mark></h2>
                        <div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt repellendus ea fugit aliquid qui vitae a hic quod quas consectetur! Vitae iste repudiandae animi eligendi natus harum quod architecto doloremque.</p>
                        </div>
                    </div>
                </div>
            HTML;
            echo $table;
        }else{
            $table = <<<HTML
                <div class="room">
                    <div class="image">
                        <img src="../rooms/$image" alt="room" width='300px' height='200px'>
                    </div>
                    <div class="text-section">
                        <h2 class="room-title">$room_name</h2>
                        <div>
                            <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Nesciunt repellendus ea fugit aliquid qui vitae a hic quod quas consectetur! Vitae iste repudiandae animi eligendi natus harum quod architecto doloremque.</p>
                        </div>
                    </div>
                </div>
             HTML;
             echo $table;
        }

        
    }

}

?>