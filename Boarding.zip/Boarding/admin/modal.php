<?php 

if(isset($_GET['modal'])){

    $html = <<<HTML
        <div class='modal'>
            <form method="post" enctype='multipart/form-data'>
                <h3>ADD ROOM</h3>
                <hr>
                <div >
                    <label for="file">Room Image </label>
                    <input required type="file" id="file" name="file"  >
                </div>
                <div>
                    <label for="room_name">Room Name</label>
                    <input required type="text" name='room_name' id='room_name'>
                </div>
                <div>
                    <label for="price">Price</label>
                    <input required type="number" name='price' id='price'>
                </div>
                <div>
                    <button name='btn'>Submit</button>
                </div>
            </form>
        </div>
    HTML;

    echo $html;

}


?>