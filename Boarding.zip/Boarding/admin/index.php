<?php
include("../config.php");
session_start();
if(!isset($_SESSION['admin'])){
    header("location:../index.php");
}else{
    $id = $_SESSION['id'];
}


?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width='device-width', initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="../fontawesome-free-6.5.1-web/css/all.min.css">
    <link rel="stylesheet" href="../style/admin.css">
</head>

<body>

    <div class="parent">
        <div class="div1">
            <form action="">
                <input type="text" placeholder="Search" name="search"><button id="search">Search</button>
            </form>
            <h2 class="fa-solid fa-bars" ></h2>
            <div>
                <ul>
                    <li>
                        <a href="">Hello World</a>
                    </li>
                    <li>
                        <a href="">Hello World</a>
                    </li>
                    <li>
                        <a onclick="get_modal()">Add Room</a>
                    </li>
                    <li>
                        <a onclick="show_tenants(<?php echo $id;?>)">Manage Tenants</a>
                    </li>
                    <li>
                        <a onclick="show_rooms(<?php echo $id;?>)">Manage Rooms</a>
                    </li>
                    <li>
                        <a href="../logout.php">Logout</a>
                    </li>
                </ul>
            </div>
        </div>
        <div class="div2">
            <ul>
                <h2>Admin</h2>
                <hr>
                <li>
                    <a href="">Hello World</a>
                </li>
                <li>
                    <a>Sales and Revenue</a>
                </li>
                <h3>Manage</h3>
                <hr>
                <li>
                    <a onclick="get_modal()">Add Room</a>
                </li>
                <li>
                    <a onclick="show_tenants(<?php echo $id;?>)">Manage Tenant</a>
                </li>
                <li>
                    <a onclick="show_rooms(<?php echo $id;?>)">Manage Room</a>
                </li>
                <li>
                    <a href="../logout.php">Logout</a>
                </li>
            </ul>
        </div>
        <div class="div3" id="display">

        </div>

        <div class="div4" style="display: flex; justify-content:center;">
            <canvas id="myChart" style="width:100%;max-width:300px"></canvas>
        </div>

        <div class="div5" id="customers">

            <canvas id="barChart" style="width:100%;max-width:300px"></canvas>

        </div>
    </div>

    <script>
        function get_modal() {
            const xhr = new XMLHttpRequest();
            xhr.open("GET", 'modal.php?modal', true);
            xhr.onload = function() {
                if (this.status == 200) {
                    document.getElementById('display').innerHTML = this.responseText;
                }
            }
            xhr.send();
        }

        function show_rooms(id){
            const xhr = new XMLHttpRequest();
            xhr.open("GET", `room_list.php?landlord_id=${id}`, true);
            xhr.onload = function() {
                if (this.status == 200) {
                    document.getElementById('display').innerHTML = this.responseText;
                }
            }
            xhr.send();
        }

        function show_tenants(id){
            const xhr = new XMLHttpRequest();
            xhr.open("GET", `show_tenants.php?landlord_id=${id}`, true);
            xhr.onload = function() {
                if (this.status == 200) {
                    document.getElementById('display').innerHTML = this.responseText;
                }
            }
            xhr.send();
        }
    </script>

</body>

</html>

<?php

if (isset($_POST['btn'])) {
    $room_name = $_POST['room_name'];
    $price = $_POST['price'];
    $file = $_FILES['file'];
    $temp = $file['tmp_name'];
    $current_extension = pathinfo($file['name'])['extension'];
    $allowed_extension = array('png', 'jpg', 'jpeg');
    $dest = '../room/' . uniqid('', true) . '.' . $current_extension;

    if (in_array($current_extension, $allowed_extension)) {
        move_uploaded_file($temp, $dest);
        
        $sql = "insert into rooms(image, room_name, price,bh_id)
                values('$dest','$room_name',$price,$id);
            ";
    
        if (mysqli_query($connection, $sql)) {

        };

    }

}


?>