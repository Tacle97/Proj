<?php 

$server = "localhost";
$username = "root";
$pass = "";
$db = "boarding_house_db";

$connection = mysqli_connect($server,$username,$pass);
$sql = "create database if not exists $db";
mysqli_query($connection,$sql);

$connection = mysqli_connect($server,$username,$pass,$db);

$sql = "create table if not exists landlords(
    id int auto_increment primary key ,
    name varchar(100),
    email varchar(100) unique,
    number varchar(50) unique,
    password varchar(100)
)";
mysqli_query($connection,$sql);


$sql = "create table if not exists tenants(
    id int auto_increment primary key,
    name varchar(100),
    email varchar(100) unique,
    number varchar(50) unique,
    password varchar(100)
    )";
    
mysqli_query($connection,$sql);


$sql = "create table if not exists rooms(
	id int auto_increment primary key,
    room_name varchar(100),
    image varchar(100),
    price double,
    rating int,
    tenant_id int,
	FOREIGN KEY (tenant_id) REFERENCES tenants(id) on delete cascade,
    bh_id int,
    FOREIGN KEY (bh_id) REFERENCES landlords(id) on delete cascade
);";
mysqli_query($connection,$sql);

?>