<?php 
include('config.php');
session_start();
if(isset($_SESSION['tenant'])){
    $tenant_id = $_SESSION['tenant_id'];
}

if(isset($_GET['room_id'])){
    $room_id = $_GET['room_id'];
}

$sql = "select * from rooms where id = $room_id";
$res = mysqli_query($connection,$sql);
$data = mysqli_fetch_assoc($res);

?>
<!DOCTYPE html>
<html>
    
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Document</title>
        <link rel="stylesheet" href="./style/user.css">
    </head>
    
    <body>
    
        <div class="parent">
            <div class="div1">
                <form method="post" title='fill up to take room'>
                    <h2>TAKE ROOM</h2>
                    <hr>
                    <div class="form-group">
                        <label for="name">Name</label>
                        <input autocomplete="off" required type="text" name="name" id="name" width="">
                    </div>
                    <div class="form-group">
                        <label for="pass">Password</label>
                        <input autocomplete="off" required type="text" name="pass" id="pass">
                    </div>
                    <div class="btn-group">
                        <button name="btn">Take</button>
                    </div>
                    <hr>
                  
                </form>
            </div>
            <div class="div2">
                <img src=<?php echo $data['image'];?> alt="room">
            </div>
        </div>
    
    
    </body>
</html>

</html>
<?php 

if(isset($_POST['btn'])){
    $sql = "update rooms set tenant_id = $tenant_id where id = $room_id";
    if(mysqli_query($connection,$sql)){
        header("location:home.php");
    }
}

?>
