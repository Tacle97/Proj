<?php include('config.php')?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style/user.css">
</head>

<body>

    <div class="parent">
        <div class="div1">
            <form method="post">
                <h2>REGISTER</h2>
                <hr>
                <div class="col-2">
                    <div>
                        <label for="name">Name</label>
                        <input autocomplete="off" class="register-input" required type="text" name="name" id="name">
                    </div>
                    <div>
                        <label for="email">Email</label>
                        <input autocomplete="off" class="register-input" required type="text" name="email" id="email">
                    </div>
                </div>
                <div class="col-2">
                    <div>
                        <label for="number">Number</label>
                        <input autocomplete="off" class="register-input" required type="text" name="number" id="number">
                    </div>
                    <div>
                        <label for="pass">Password</label>
                        <input autocomplete="off" class="register-input" required type="text" name="pass" id="pass">
                    </div>
                </div>
                <div>
                    <label for="role">REGISTER AS</label>
                    <select name="role" id="role" class="select" >
                        <option value="tenants">TENANT</option>
                        <option value="landlords">LANDLORD</option>
                    </select>
                </div>
                <div class="btn-group">
                    <button>SUBMIT</button>
                </div>
                <hr>
                <div>
                    <p class="text-align-center">Have an account <a href="index.php">Login</a></p>
                </div>
            </form>
        </div>
        <div class="div2">
            <img src="./image/logo.png" alt="" width="400px" height="350px" class="logo">
        </div>
    </div>

</body>

</html>

<?php 

if($_SERVER['REQUEST_METHOD']=="POST"){
    $name = $_POST['name'];
    $email = $_POST['email'];
    $number = $_POST['number'];
    $pass = $_POST['pass'];
    $role = $_POST['role'];

    if($role == 'tenants'){
        $sql = "insert into $role(name,email,number,password) 
        values('$name','$email','$number','$pass')";
        if(mysqli_query($connection,$sql)){
            header("location:index.php");
        }
    }else if($role == 'landlords'){
        $sql = "insert into $role(name,email,number,password) 
        values('$name','$email','$number','$pass')";
        if(mysqli_query($connection,$sql)){
            header("location:index.php");
        }
    }
}


?>