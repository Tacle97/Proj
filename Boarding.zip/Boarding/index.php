<?php include("config.php")?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="./style/user.css">
</head>

<body>

    <div class="parent">
        <div class="div1">
            <form method="post">
                <h2>LOGIN</h2>
                <hr>
                <div class="form-group">
                    <label for="name">Name</label>
                    <input autocomplete="off" required type="text" name="name" id="name" width="">
                </div>
                <div class="form-group">
                    <label for="pass">Password</label>
                    <input autocomplete="off" required type="text" name="pass" id="pass">
                </div>
                <div class="form-group">
                    <label for="name">Login as</label>
                    <select name="role" id="role" class="role">
                        <option value="tenants">TENANT</option>
                        <option value="landlords">LANDLORD</option>
                    </select>
                </div>
                <div class="btn-group">
                    <button>LOGIN</button>
                </div>
                <hr>
                <div class="ubos">
                    <p class="text-align-center">Don't have an account <a href="register.php">Register</a></p>
                </div>
            </form>
        </div>
        <div class="div2">
            <img src="./image/logo.png" alt="" width="350px">
        </div>
    </div>


</body>
</html>

<?php 

if($_SERVER['REQUEST_METHOD']=="POST"){
    $name = $_POST['name'];
    $pass = $_POST['pass'];
    $role = $_POST['role'];

    if($role == 'tenants'){

        $sql = "select * from $role where name = '$name' and password = '$pass' limit 1 ";
        $res = mysqli_query($connection,$sql);
        $num_rows = mysqli_num_rows($res);
        $data = mysqli_fetch_assoc($res);
        $id = $data['id'];

        if($num_rows > 0){
            session_start();
            $_SESSION['tenant_id'] = $id;
            $_SESSION['tenant'] = true;
            header("location:home.php");
        }
        
    }else if($role == 'landlords'){
        $sql = "select * from $role where name = '$name' and password = '$pass' limit 1 ";
        $res = mysqli_query($connection,$sql);
        $num_rows = mysqli_num_rows($res);
        $data = mysqli_fetch_assoc($res);
        
        if($num_rows > 0){
            session_start();
            $_SESSION['admin'] = true;
            $_SESSION['id'] = $data['id'];
            header("location:./admin/index.php");
        }

        
    }
}



?>